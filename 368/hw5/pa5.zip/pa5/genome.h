#include <stdio.h> //needed for printf
#include <string.h>
#include <stdlib.h> //needed for EXIT_SUCCESS

int *Longest_conserved_gene_sequence(char *filename, int *size_of_seq);
