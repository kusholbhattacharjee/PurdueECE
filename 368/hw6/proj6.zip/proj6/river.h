#include <stdlib.h>
#include <stdio.h>

int* nodes;
int* turns;
void readFile(char* file, int* R, int* C);
int BIG_D(int R, int C);

